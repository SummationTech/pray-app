//
//  CarListViewController.h
//  AddItemTableViewDemo
//
//  Created by Arthur Knopper on 15-06-13.
//  Copyright (c) 2013 Arthur Knopper. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CarDetailViewController.h"

@interface CarListViewController : UITableViewController

@end
