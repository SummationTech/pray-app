//
//  BookListViewController.h
//  CoreDataDemo
//
//  Created by Arthur Knopper on 21/11/12.
//  Copyright (c) 2012 iOSCreator. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookListViewController : UIViewController

@end
