//
//  ColorController.swift
//  IOS8SwiftTabBarControllerTutorial
//
//  Created by Arthur Knopper on 08/07/15.
//  Copyright (c) 2015 Arthur Knopper. All rights reserved.
//

import UIKit

class ColorController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
